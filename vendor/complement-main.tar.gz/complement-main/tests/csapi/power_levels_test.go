package csapi_tests

import (
	"fmt"
	"testing"

	"github.com/matrix-org/complement/runtime"
	"github.com/tidwall/gjson"

	"github.com/matrix-org/complement"
	"github.com/matrix-org/complement/b"
	"github.com/matrix-org/complement/client"
	"github.com/matrix-org/complement/helpers"
	"github.com/matrix-org/complement/match"
	"github.com/matrix-org/complement/must"
	"github.com/matrix-org/gomatrixserverlib"
	"github.com/matrix-org/gomatrixserverlib/spec"
)

// This test ensures that an authorised (PL 100) user is able to modify the users_default value
// when that value is equal to the value of authorised user.
// Regression test for https://github.com/matrix-org/gomatrixserverlib/pull/306
func TestDemotingUsersViaUsersDefault(t *testing.T) {
	deployment := complement.Deploy(t, 1)
	defer deployment.Destroy(t)

	alice := deployment.Register(t, "hs1", helpers.RegistrationOpts{})
	bob := deployment.Register(t, "hs1", helpers.RegistrationOpts{})

	defaultRoomVersion := alice.GetDefaultRoomVersion(t)

	roomID := alice.MustCreateRoom(t, map[string]interface{}{
		"preset": "public_chat",
		"power_level_content_override": func() map[string]interface{} {
			power_level_content := map[string]interface{}{
				"users_default": 100, // the default is 0
				"users": map[string]int64{
					alice.UserID: 100,
					bob.UserID:   100,
				},
				"events":        map[string]int64{},
				"notifications": map[string]int64{},
			}
			// Remove the room creator if this is a v12+ room
			if gomatrixserverlib.MustGetRoomVersion(defaultRoomVersion).PrivilegedCreators() {
				delete(power_level_content["users"].(map[string]int64), alice.UserID)
			}
			return power_level_content
		}(),
	})

	bob.MustJoinRoom(t, roomID, []spec.ServerName{
		deployment.GetFullyQualifiedHomeserverName(t, "hs1"),
	})

	bob.SendEventSynced(t, roomID, b.Event{
		Type:     spec.MRoomPowerLevels,
		StateKey: b.Ptr(""),
		Content: func() map[string]interface{} {
			content := map[string]interface{}{
				"users_default": 40, // we change the default to 40. We should be able to do this.
				"users": map[string]int64{
					alice.UserID: 100,
					bob.UserID:   100,
				},
				"events":        map[string]int64{},
				"notifications": map[string]int64{},
			}
			// Remove the room creator if this is a v12+ room
			if gomatrixserverlib.MustGetRoomVersion(defaultRoomVersion).PrivilegedCreators() {
				delete(content["users"].(map[string]int64), alice.UserID)
			}
			return content
		}(),
	})
}

func TestPowerLevels(t *testing.T) {
	deployment := complement.Deploy(t, 1)
	defer deployment.Destroy(t)

	alice := deployment.Register(t, "hs1", helpers.RegistrationOpts{})

	defaultRoomVersion := alice.GetDefaultRoomVersion(t)

	roomID := alice.MustCreateRoom(t, map[string]interface{}{})

	// sytest: GET /rooms/:room_id/state/m.room.power_levels can fetch levels
	t.Run("GET /rooms/:room_id/state/m.room.power_levels can fetch levels", func(t *testing.T) {
		// Venator skips marshalling default values, which means all of these checks fail:
		// > MatchJSONBytes key 'ban' missing with input = {}
		// This is a feature :D
		runtime.SkipIf(t, runtime.Venator)
		// Test if the old state still exists
		// note: before v10 we technically cannot assume that powerlevel integers are json numbers,
		//  as they can be both strings and numbers.
		// However, for this test, we control the test environment,
		//  and we will assume the server is sane and give us powerlevels as numbers,
		//  and if it doesn't, that's an offense worthy of a frown.
		// note 2: before v12 the `users` object had to explicitly define the room creator, if they
		//  should have some power level other than the room's default. Starting with v12, this user
		//  is to be excluded from the `users` object, as they have an infinite power level that is
		//  not representable in JSON
		content := alice.MustGetStateEventContent(t, roomID, spec.MRoomPowerLevels, "")
		must.MatchGJSON(t, content,
			match.JSONKeyTypeEqual("ban", gjson.Number),
			match.JSONKeyTypeEqual("kick", gjson.Number),
			match.JSONKeyTypeEqual("redact", gjson.Number),
			match.JSONKeyTypeEqual("state_default", gjson.Number),
			match.JSONKeyTypeEqual("events_default", gjson.Number),
			match.JSONKeyTypeEqual("users_default", gjson.Number),

			match.JSONMapEach("events", func(k, v gjson.Result) error {
				if v.Type != gjson.Number {
					return fmt.Errorf("key %s is not a number", k.Str)
				} else {
					return nil
				}
			}),

			match.JSONMapEach("users", func(k, v gjson.Result) error {
				if v.Type != gjson.Number {
					return fmt.Errorf("key %s is not a number", k.Str)
				} else {
					return nil
				}
			}),

			func(body gjson.Result) error {
				// This key should be missing for room v12+
				if gomatrixserverlib.MustGetRoomVersion(defaultRoomVersion).PrivilegedCreators() {
					must.MatchGJSON(t, body, match.JSONKeyMissing("users."+client.GjsonEscape(alice.UserID)))
					return nil
				} else {
					userDefault := int(body.Get("users_default").Num)
					thisUser := int(body.Get("users." + client.GjsonEscape(alice.UserID)).Num)
					if thisUser > userDefault {
						return nil
					} else {
						return fmt.Errorf("expected room creator (%d) to have a higher-than-default powerlevel (which is %d)", thisUser, userDefault)
					}
				}
			},
		)
	})

	// sytest: PUT /rooms/:room_id/state/m.room.power_levels can set levels
	t.Run("PUT /rooms/:room_id/state/m.room.power_levels can set levels", func(t *testing.T) {
		// note: these need to be floats to allow a roundtrip comparison
		PLContent := map[string]interface{}{
			"invite": 100.0,
			"users": map[string]interface{}{
				alice.UserID:                    100.0,
				"@random-other-user:their.home": 20.0,
			},
		}

		// Rooms versioned 12+ do not allow having the room creator in the 'users' object, so just remove it
		if gomatrixserverlib.MustGetRoomVersion(defaultRoomVersion).PrivilegedCreators() {
			delete(PLContent["users"].(map[string]interface{}), alice.UserID)
		}

		eventId := alice.SendEventSynced(t, roomID, b.Event{
			Type:     spec.MRoomPowerLevels,
			StateKey: b.Ptr(""),
			Content:  PLContent,
		})

		res := alice.MustDo(
			t,
			"GET",
			[]string{"_matrix", "client", "v3", "rooms", roomID, "event", eventId},
		)

		must.MatchResponse(t, res, match.HTTPResponse{
			JSON: []match.JSON{
				match.JSONKeyEqual("content", PLContent),
			},
		})
	})

	// sytest: PUT power_levels should not explode if the old power levels were empty
	t.Run("PUT power_levels should not explode if the old power levels were empty", func(t *testing.T) {
		// Absence of an "events" key
		alice.SendEventSynced(t, roomID, b.Event{
			Type:     spec.MRoomPowerLevels,
			StateKey: b.Ptr(""),
			Content: func() map[string]interface{} {
				PLContent := map[string]interface{}{
					"users": map[string]int64{
						alice.UserID: 100,
					},
				}
				// Rooms versioned 12+ do not allow having the room creator in the 'users' object, so just remove the
				// single user so the empty `users` object is present
				if gomatrixserverlib.MustGetRoomVersion(defaultRoomVersion).PrivilegedCreators() {
					delete(PLContent["users"].(map[string]int64), alice.UserID)
				}
				return PLContent
			}(),
		})

		// Absence of a "users" key
		alice.SendEventSynced(t, roomID, b.Event{
			Type:     spec.MRoomPowerLevels,
			StateKey: b.Ptr(""),
			Content:  map[string]interface{}{},
		})

		// This part of the test should check that sending a power_levels event fails. As then the previous
		// power_levels event should not have changed. Depending on the room version, this can be done in one
		//  of two different ways:
		if gomatrixserverlib.MustGetRoomVersion(defaultRoomVersion).PrivilegedCreators() {
			// For rooms with privileged creators(MSC4289), try and send an event with the room creator in the
			// `users` object, which should be prohibited with a 400 error code. An empty `users` object appears
			// to be allowed, hence the difference from the below condition for other room versions.
			res := alice.Do(
				t,
				"PUT",
				[]string{"_matrix", "client", "v3", "rooms", roomID, "state", spec.MRoomPowerLevels},
				client.WithJSONBody(t, map[string]interface{}{
					"users": map[string]int64{
						alice.UserID: 100,
					},
				}),
			)
			must.MatchResponse(t, res, match.HTTPResponse{
				StatusCode: 400,
			})

		} else {
			// Prior to rooms using privileged creators, an empty `users` object would be prohibited and should
			// give a 403 (not a 500)
			res := alice.Do(
				t,
				"PUT",
				[]string{"_matrix", "client", "v3", "rooms", roomID, "state", spec.MRoomPowerLevels},
				client.WithJSONBody(t, map[string]interface{}{
					"users": map[string]int64{},
				}),
			)
			must.MatchResponse(t, res, match.HTTPResponse{
				StatusCode: 403,
			})

		}

		// Test if the old state still exists
		content := alice.MustGetStateEventContent(t, roomID, spec.MRoomPowerLevels, "")
		must.MatchGJSON(t, content, match.JSONKeyMissing("users"))
	})
}
