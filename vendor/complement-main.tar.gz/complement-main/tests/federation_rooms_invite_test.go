// These tests currently fail on Dendrite, due to Dendrite bugs.
//go:build !dendrite_blacklist && !venator_blacklist
// +build !dendrite_blacklist,!venator_blacklist

// Venator: does not yet implement federation

package tests

import (
	"encoding/json"
	"testing"

	"github.com/matrix-org/complement"
	"github.com/matrix-org/gomatrixserverlib/spec"
	"github.com/tidwall/gjson"

	"github.com/matrix-org/complement/b"
	"github.com/matrix-org/complement/client"
	"github.com/matrix-org/complement/helpers"
	"github.com/matrix-org/complement/match"
	"github.com/matrix-org/complement/must"
)

func TestFederationRoomsInvite(t *testing.T) {
	deployment := complement.Deploy(t, 2)
	defer deployment.Destroy(t)

	alice := deployment.Register(t, "hs1", helpers.RegistrationOpts{LocalpartSuffix: "alice"})
	alice2 := deployment.Register(t, "hs1", helpers.RegistrationOpts{LocalpartSuffix: "alice2"})
	bob := deployment.Register(t, "hs2", helpers.RegistrationOpts{LocalpartSuffix: "bob"})
	bob2 := deployment.Register(t, "hs2", helpers.RegistrationOpts{LocalpartSuffix: "bob2"})

	includeLeaveSyncFilterBytes, err := json.Marshal(map[string]interface{}{
		"room": map[string]interface{}{
			"include_leave": true,
		},
	})
	must.NotError(t, "failed to marshal include_leave filter", err)
	includeLeaveSyncFilter := string(includeLeaveSyncFilterBytes)

	t.Run("Parallel", func(t *testing.T) {
		// sytest: Invited user can reject invite over federation
		t.Run("Invited user can reject invite over federation", func(t *testing.T) {
			t.Parallel()
			roomID := alice.MustCreateRoom(t, map[string]interface{}{
				"preset": "private_chat",
				"invite": []string{bob.UserID},
			})
			bob.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob.UserID, roomID))
			bob.MustLeaveRoom(t, roomID)
			alice.MustSyncUntil(t, client.SyncReq{Filter: includeLeaveSyncFilter}, client.SyncLeftFrom(bob.UserID, roomID))
		})

		// sytest: Invited user can reject invite over federation several times
		t.Run("Invited user can reject invite over federation several times", func(t *testing.T) {
			t.Parallel()
			roomID := alice.MustCreateRoom(t, map[string]interface{}{
				"preset": "private_chat",
			})
			for i := 0; i < 3; i++ {
				alice.MustInviteRoom(t, roomID, bob.UserID)
				bob.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob.UserID, roomID))
				bob.MustLeaveRoom(t, roomID)
				alice.MustSyncUntil(t, client.SyncReq{Filter: includeLeaveSyncFilter}, client.SyncLeftFrom(bob.UserID, roomID))
			}
		})

		// sytest: Invited user can reject invite over federation for empty room
		t.Run("Invited user can reject invite over federation for empty room", func(t *testing.T) {
			t.Parallel()
			roomID := alice.MustCreateRoom(t, map[string]interface{}{
				"preset": "private_chat",
				"invite": []string{bob.UserID},
			})
			aliceSince := alice.MustSyncUntil(t, client.SyncReq{}, client.SyncJoinedTo(alice.UserID, roomID))
			bobSince := bob.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob.UserID, roomID))
			alice.MustLeaveRoom(t, roomID)
			alice.MustSyncUntil(t, client.SyncReq{Since: aliceSince, Filter: includeLeaveSyncFilter}, client.SyncLeftFrom(alice.UserID, roomID))
			bob.MustLeaveRoom(t, roomID)
			bob.MustSyncUntil(t, client.SyncReq{Since: bobSince, Filter: includeLeaveSyncFilter}, client.SyncLeftFrom(bob.UserID, roomID))
		})

		// sytest: Remote invited user can see room metadata
		t.Run("Remote invited user can see room metadata", func(t *testing.T) {
			t.Parallel()
			roomID := alice.MustCreateRoom(t, map[string]interface{}{
				"preset": "private_chat",
				"name":   "Invites room",
				"invite": []string{bob.UserID},
			})

			wantFields := map[string]string{
				"m.room.join_rules": "join_rule",
				"m.room.name":       "name",
			}
			wantValues := map[string]string{
				"m.room.join_rules": "invite",
				"m.room.name":       "Invites room",
			}

			bob.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob.UserID, roomID))
			res, _ := bob.MustSync(t, client.SyncReq{})
			verifyState(t, res, wantFields, wantValues, roomID, alice)
		})

		t.Run("Remote invited user can join the room when homeserver is already participating in the room", func(t *testing.T) {
			t.Parallel()
			roomID := alice.MustCreateRoom(t, map[string]interface{}{
				"preset": "private_chat",
			})
			alice.MustSyncUntil(t, client.SyncReq{}, client.SyncJoinedTo(alice.UserID, roomID))

			// bob1 is invited and can join the room (hs2 is now participating of the room)
			alice.MustInviteRoom(t, roomID, bob.UserID)
			bob.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob.UserID, roomID))
			bob.MustJoinRoom(t, roomID, []spec.ServerName{
				deployment.GetFullyQualifiedHomeserverName(t, "hs1"),
			})
			// Make sure alice can see bob in the room
			alice.MustSyncUntil(t, client.SyncReq{}, client.SyncJoinedTo(bob.UserID, roomID))

			// bob2 is invited and can also join the room
			alice.MustInviteRoom(t, roomID, bob2.UserID)
			bob2.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob2.UserID, roomID))
			bob2.MustJoinRoom(t, roomID, []spec.ServerName{
				deployment.GetFullyQualifiedHomeserverName(t, "hs1"),
			})
			// Make sure alice can see bob2 in the room
			alice.MustSyncUntil(t, client.SyncReq{}, client.SyncJoinedTo(bob2.UserID, roomID))
		})

		t.Run("Remote invited user can reject invite when homeserver is already participating in the room", func(t *testing.T) {
			t.Parallel()
			roomID := alice.MustCreateRoom(t, map[string]interface{}{
				"preset": "private_chat",
			})
			alice.MustSyncUntil(t, client.SyncReq{}, client.SyncJoinedTo(alice.UserID, roomID))

			// bob1 is invited and can join the room (hs2 is now participating of the room)
			alice.MustInviteRoom(t, roomID, bob.UserID)
			bob.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob.UserID, roomID))
			bob.MustJoinRoom(t, roomID, []spec.ServerName{
				deployment.GetFullyQualifiedHomeserverName(t, "hs1"),
			})
			// Make sure alice can see bob in the room
			alice.MustSyncUntil(t, client.SyncReq{}, client.SyncJoinedTo(bob.UserID, roomID))

			// bob2 is invited and can reject the invite (leave the room)
			alice.MustInviteRoom(t, roomID, bob2.UserID)
			bob2.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob2.UserID, roomID))
			bob2.MustLeaveRoom(t, roomID)
			// Make sure alice can see bob2 left the room
			alice.MustSyncUntil(t, client.SyncReq{Filter: includeLeaveSyncFilter}, client.SyncLeftFrom(bob2.UserID, roomID))
		})

		t.Run("Inviter user can rescind invite over federation", func(t *testing.T) {
			t.Parallel()
			roomID := alice.MustCreateRoom(t, map[string]interface{}{
				"preset": "private_chat",
				"invite": []string{bob.UserID},
			})
			bob.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob.UserID, roomID))
			alice.MustDo(t, "POST", []string{"_matrix", "client", "v3", "rooms", roomID, "kick"},
				client.WithJSONBody(t, map[string]interface{}{
					"user_id": bob.UserID,
					"reason":  "testing",
				}),
			)

			bob.MustSyncUntil(t, client.SyncReq{Filter: includeLeaveSyncFilter}, client.SyncLeftFrom(bob.UserID, roomID))
		})

		t.Run("Non-invitee user cannot rescind invite over federation", func(t *testing.T) {
			t.Parallel()

			// First create a room that Bob is in. This is so that later we can
			// send a message to test that Bob doesn't see the rescission.
			roomID1 := alice.MustCreateRoom(t, map[string]interface{}{
				"preset": "private_chat",
				"invite": []string{bob.UserID},
			})
			since := bob.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob.UserID, roomID1))
			bob.MustJoinRoom(t, roomID1, []spec.ServerName{})

			// Second room which Alice and Alice2 join, Alice2 invites Bob and
			// then Alice kicks him.
			roomID2 := alice.MustCreateRoom(t, map[string]interface{}{
				"preset": "private_chat",
				"invite": []string{alice2.UserID},
			})
			alice2.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(alice2.UserID, roomID2))
			alice2.MustJoinRoom(t, roomID2, []spec.ServerName{})

			alice2.MustInviteRoom(t, roomID2, bob.UserID)
			bob.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob.UserID, roomID2))

			// Alice, not the original inviter, kicks bob. This does not result
			// in bob seeing the rescission.
			alice.MustDo(t, "POST", []string{"_matrix", "client", "v3", "rooms", roomID2, "kick"},
				client.WithJSONBody(t, map[string]interface{}{
					"user_id": bob.UserID,
					"reason":  "testing",
				}),
			)

			// Check bob *doesn't* see the rescission. We do this by sending a
			// message in room1 and checking that once Bob receives that message
			// he still hasn't seen the leave.
			eventID := alice.SendEventSynced(t, roomID1, b.Event{
				Type: "m.room.message",
				Content: map[string]interface{}{
					"body":    "1",
					"msgtype": "m.text",
				},
				Sender: alice.UserID,
			})
			bob.MustSyncUntil(t, client.SyncReq{Since: since}, client.SyncTimelineHasEventID(roomID1, eventID))

			// Check bob is still invited by doing an initial sync
			bob.MustSyncUntil(t, client.SyncReq{}, client.SyncInvitedTo(bob.UserID, roomID2))
		})

		t.Run("Invited user has 'is_direct' flag in prev_content after joining", func(t *testing.T) {
			roomID := alice.MustCreateRoom(t, map[string]interface{}{
				"preset": "private_chat",
				"name":   "Invites room",
				// invite Bob and make the room a DM, so we can verify m.direct flag is in the prev_content after joining
				"invite":    []string{bob.UserID},
				"is_direct": true,
			})
			bob.MustJoinRoom(t, roomID, []spec.ServerName{})

			bob.MustSyncUntil(t, client.SyncReq{}, client.SyncJoinedTo(bob.UserID, roomID, func(ev gjson.Result) bool {
				must.MatchGJSON(t, ev,
					match.JSONKeyEqual("unsigned.prev_content.membership", "invite"),
					match.JSONKeyEqual("unsigned.prev_content.is_direct", true),
					match.JSONKeyEqual("unsigned.prev_sender", alice.UserID),
				)
				return true
			}))
		})
	})
}

// verifyState checks that the fields in "wantFields" are present in invite_state.events
func verifyState(t *testing.T, res gjson.Result, wantFields, wantValues map[string]string, roomID string, cl *client.CSAPI) {
	inviteEvents := res.Get("rooms.invite." + client.GjsonEscape(roomID) + ".invite_state.events")
	if !inviteEvents.Exists() {
		t.Errorf("expected invite events, but they don't exist")
	}
	for _, event := range inviteEvents.Array() {
		eventType := event.Get("type").Str
		field, ok := wantFields[eventType]
		if !ok {
			continue
		}
		wantValue := wantValues[eventType]
		eventStateKey := event.Get("state_key").Str

		res := cl.MustDo(t, "GET", []string{"_matrix", "client", "v3", "rooms", roomID, "state", eventType, eventStateKey})

		must.MatchResponse(t, res, match.HTTPResponse{
			JSON: []match.JSON{
				match.JSONKeyEqual(field, wantValue),
			},
		})
	}
}
